/**
 * Definición de constantes
 *
 * @author demorales13@gmail.com
 * @since 3-dic-2016
 *
 */

(function () {
	'use strict';

    angular.module('AdsbApp')
	       .constant('BaseUri', {
	  	        apiKey: "AIzaSyAPsDLUl-siK8xadixI8emwb0N08JEhzpY",
		        authDomain: "rowlot-c9891.firebaseapp.com",
		        databaseURL: "https://rowlot-c9891.firebaseio.com",
		        storageBucket: "rowlot-c9891.appspot.com",
		        messagingSenderId: "844762296892"
           })		   
})();
